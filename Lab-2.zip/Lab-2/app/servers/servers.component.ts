import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {
  serverName = '';
  serverCreationStatus = '';
  isServerCreated = false;

  servers = ['Productionserver', 'Qaserver', 'Devserver'];

  getServers() {
    return this.servers;
  }
  ngOnInit() {
  }

  onCreateServer() {
    if(this.serverName != '') {
      this.serverCreationStatus = "Server created: " + this.serverName;
      this.servers.push(this.serverName);
      this.isServerCreated = true;
    } else {
      this.serverCreationStatus = '';
    }
  }

}
