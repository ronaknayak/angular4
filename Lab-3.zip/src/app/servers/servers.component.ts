import { Component, OnInit, EventEmitter, Output } from '@angular/core';

import { Server } from '../model/server.model';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {
  serverName = '';
  serverCreationStatus = '';
  isServerCreated = false;
  
  private servers: Server[] = [
    new Server('Productionserver'), 
    new Server('Qaserver'),
    new Server('Devserver')
  ];
  
  @Output('message') serverCreationEvent = new EventEmitter<Server>()
  
  
  getServers() {
    return this.servers;
  }
  ngOnInit() {
  }

  onCreateServer() {
    if(this.serverName != '') {
      this.serverCreationStatus = "Server created: " + this.serverName;
      this.servers.push(new Server(this.serverName));
      this.isServerCreated = true;
    } else {
      this.serverCreationStatus = '';
    }
    //To pass data to the parent level
    this.serverCreationEvent.emit(new Server(this.serverName));
  }

}
