export class Server {
    public name: string;

    constructor(name: string) {
        this.name = name;
    }
}