import { Component, OnInit, Input } from '@angular/core';

import { Server } from '../model/server.model';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  styleUrls: ['./server.component.css']
})
export class ServerComponent implements OnInit {

  serverStatus = ''
  @Input('serverEle') server: Server;
  

  constructor() { 
    this.serverStatus = Math.random() > 0.5 ? 'Active' : 'Inactive';
  }

  ngOnInit() {
  }

  getServerStatus() {
    return this.serverStatus;
  }

  getColor() {
    return this.serverStatus === 'Active' ? 'green' : 'red';
  }
}
