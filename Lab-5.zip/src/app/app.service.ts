import {Injectable,Output,EventEmitter} from '@angular/core';

import {Server} from './model/server.model';

export class AppService {
    //@Output('message') serverCreationEvent = new EventEmitter<Server>();
    serverCreationEvent = new EventEmitter<Server[]>();
    private servers: Server[] = [
        new Server('Productionserver'), 
        new Server('Qaserver'),
        new Server('Devserver')
    ];

    getServers() {
        return this.servers.slice();
    }

    addServer(server : Server) {
        this.servers.push(server);
        this.serverCreationEvent.emit(this.servers.slice())
    }
}