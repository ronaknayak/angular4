import { Component, OnInit} from '@angular/core';

import { Server } from './model/server.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'New Begining';
  createdServer: Server = new Server(null);

  ngOnInit() {
    
  }
  lastCreatedServer($event) {
    this.createdServer = $event;
  }
}
