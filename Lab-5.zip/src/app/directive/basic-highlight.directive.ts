import { 
    Directive, 
    OnInit, 
    Renderer2, 
    ElementRef, 
    HostBinding,
    HostListener 
} from '@angular/core';

@Directive({
    selector: '[appBasicHighlight]'
})
export class BasicHighlightDirective implements OnInit {
    @HostBinding('style.backgroundColor') backgroundColor : string = 'transparent';

    constructor(private elementRef : ElementRef, private renderer : Renderer2) {
    }

    ngOnInit() {
        //this.renderer.setStyle(this.elementRef.nativeElement, 'background-color','pink');
    }

    @HostListener('mouseenter') mouseover(eventData : Event) {
        this.backgroundColor='pink';
    }

    @HostListener('mouseleave') mouseleave(eventData : Event) {
        this.backgroundColor='transparent';
    }
}