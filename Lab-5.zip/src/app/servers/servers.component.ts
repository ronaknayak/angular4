import { Component, OnInit, EventEmitter, Output } from '@angular/core';

import { Server } from '../model/server.model';
import { AppService } from '../app.service';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {
  serverName = '';
  serverCreationStatus = '';
  isServerCreated = false;
  servers: Server[];
  @Output('message') newServerCreationEvent = new EventEmitter<Server>();
  
  ngOnInit() {
    this.servers = this.appService.getServers();
    this.appService.serverCreationEvent
    .subscribe(
      (updatedServerList : Server[]) => {
        this.servers = updatedServerList;
      }
    )
  }

  constructor(private appService : AppService) {
  }

  getServers() {
    //Calling service
    return this.appService.getServers();
  }

  onCreateServer() {
    if(this.serverName != '') {
      this.serverCreationStatus = "Server created: " + this.serverName;
     
      //Calling service
      this.appService.addServer(new Server(this.serverName));
      this.isServerCreated = true;
    } else {
      this.serverCreationStatus = '';
    }
    this.newServerCreationEvent.emit(new Server(this.serverName));
  }

}
